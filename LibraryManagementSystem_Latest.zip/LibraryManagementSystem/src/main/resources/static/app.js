const api = "/api";

const coverClasses = ["c1","c2","c3","c4","c5","c6","c7","c8"];
const bookIcons = ["JAVA","SQL","CODE","JAVA","NETWORKS","CODE","AI","PATTERNS"];

async function get(url) {
    const response = await fetch(api + url);
    if (!response.ok) throw new Error("API error");
    return response.json();
}

async function loadDashboard() {
    const d = await get("/dashboard");
    document.getElementById("totalBooks").textContent = d.totalBooks;
    document.getElementById("availableBooks").textContent = d.availableBooks;
    document.getElementById("members").textContent = d.members;
    document.getElementById("activeBorrowings").textContent = d.activeBorrowings;
}

async function loadMembers() {
    const members = await get("/members");
    document.getElementById("memberSelect").innerHTML = members.map(m =>
        `<option value="${m.id}">${escapeHtml(m.name)} — ${m.credits} credits</option>`
    ).join("");
}

async function loadBooks() {
    const books = await get("/books");
    const available = books.filter(b => b.available);
    const bookSelect = document.getElementById("bookSelect");

    bookSelect.innerHTML = available.length
        ? available.map(b => `<option value="${b.id}">${escapeHtml(b.title)} — ${escapeHtml(b.author || "")}</option>`).join("")
        : `<option value="">No books available</option>`;

    document.getElementById("bookGrid").innerHTML = books.map((b, i) => `
        <article class="book-card">
            <div class="cover ${coverClasses[i % coverClasses.length]}">
                <span>${escapeHtml(bookIcons[i % bookIcons.length])}<br><small>${escapeHtml(b.category || "BOOK")}</small></span>
            </div>
            <h3>${escapeHtml(b.title)}</h3>
            <div class="author">by ${escapeHtml(b.author || "Unknown author")}</div>
            <div class="book-meta">
                <span class="tag">${escapeHtml(b.category || "General")}</span>
                <span class="${b.available ? "available" : "unavailable"}">${b.available ? "● AVAILABLE" : "● BORROWED"}</span>
            </div>
        </article>
    `).join("");
}

async function loadBorrowings() {
    const active = await get("/borrowings/active");
    document.getElementById("borrowSelect").innerHTML = active.length
        ? active.map(r => `<option value="${r.id}">#${r.id} — ${escapeHtml(r.bookTitle)} — due ${r.dueDate}</option>`).join("")
        : `<option value="">No active borrowings</option>`;

    const history = await get("/borrowings");
    document.getElementById("historyTable").innerHTML = history.length
        ? history.map(r => `
            <tr>
                <td>#${r.id}</td>
                <td><b>${escapeHtml(r.memberName)}</b></td>
                <td>${escapeHtml(r.bookTitle)}</td>
                <td>${r.withdrawDate}</td>
                <td>${r.dueDate}</td>
                <td>${r.returnDate || "—"}</td>
                <td>${formatStatus(r.status)}</td>
                <td>${r.creditsEarned > 0 ? "+" : ""}${r.creditsEarned}</td>
            </tr>`).join("")
        : `<tr><td colspan="8">No borrowing history yet.</td></tr>`;
}

function formatStatus(status) {
    return status.replaceAll("_", " ");
}

async function borrowBook() {
    const memberId = Number(document.getElementById("memberSelect").value);
    const bookId = Number(document.getElementById("bookSelect").value);
    const msg = document.getElementById("borrowMessage");

    if (!memberId || !bookId) {
        msg.textContent = "Please select a member and an available book.";
        return;
    }

    const response = await fetch(api + "/borrow", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({memberId, bookId})
    });
    const data = await response.json();

    if (!response.ok) {
        msg.textContent = "✕ " + data.error;
        return;
    }

    msg.textContent = `✓ Withdrawn successfully · Due ${data.dueDate}`;
    await loadAll();
}

async function returnBook() {
    const borrowId = Number(document.getElementById("borrowSelect").value);
    const msg = document.getElementById("returnMessage");

    if (!borrowId) {
        msg.textContent = "No active borrowing selected.";
        return;
    }

    const response = await fetch(api + "/return/" + borrowId, {method: "POST"});
    const data = await response.json();

    if (!response.ok) {
        msg.textContent = "✕ " + data.error;
        return;
    }

    msg.textContent = data.creditsEarned > 0
        ? `✦ Returned on time · +${data.creditsEarned} credits earned`
        : "Returned late · No credits awarded";

    await loadAll();
}

async function loadAll() {
    try {
        await Promise.all([loadDashboard(), loadMembers(), loadBooks(), loadBorrowings()]);
    } catch (e) {
        console.error(e);
        document.querySelectorAll(".message").forEach(x =>
            x.textContent = "⚠ Start Spring Boot and MySQL, then refresh the page."
        );
    }
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[c]));
}

loadAll();
