CREATE DATABASE IF NOT EXISTS library_management;
USE library_management;

CREATE TABLE IF NOT EXISTS members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20),
    credits INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS books (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(120),
    category VARCHAR(100),
    available BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS borrow_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL,
    book_id INT NOT NULL,
    withdraw_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'BORROWED',
    credits_earned INT NOT NULL DEFAULT 0,
    FOREIGN KEY (member_id) REFERENCES members(id),
    FOREIGN KEY (book_id) REFERENCES books(id)
);

INSERT IGNORE INTO members (id, name, email, phone, credits) VALUES
(1, 'Snehitha', 'snehitha@example.com', '9876543210', 50),
(2, 'Rahul', 'rahul@example.com', '9876543211', 30),
(3, 'Ananya', 'ananya@example.com', '9876543212', 40);

INSERT IGNORE INTO books (id, title, author, category, available) VALUES
(1, 'Java Programming', 'Herbert Schildt', 'Programming', TRUE),
(2, 'Database System Concepts', 'Abraham Silberschatz', 'Database', TRUE),
(3, 'Clean Code', 'Robert C. Martin', 'Software Engineering', TRUE),
(4, 'Head First Java', 'Kathy Sierra', 'Programming', TRUE),
(5, 'Computer Networks', 'Andrew S. Tanenbaum', 'Networks', TRUE),
(6, 'The Pragmatic Programmer', 'David Thomas', 'Programming', TRUE),
(7, 'Artificial Intelligence', 'Stuart Russell', 'AI & ML', TRUE),
(8, 'Design Patterns', 'Erich Gamma', 'Software Engineering', TRUE),
(9, 'Python Crash Course', 'Eric Matthes', 'Programming', TRUE),
(10, 'Operating System Concepts', 'Abraham Silberschatz', 'Operating Systems', TRUE),
(11, 'Computer Architecture', 'David Patterson', 'Computer Science', TRUE),
(12, 'Learning SQL', 'Alan Beaulieu', 'Database', TRUE);
